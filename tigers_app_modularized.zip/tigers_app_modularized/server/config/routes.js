var tigers = require('../controllers/tigers.js');

module.exports = function(app) {
  app.get('/', function(req, res){
    tigers.index(req, res);
  }),
  app.get('/new', function(req,res){
    tigers.show_blank_new_form(req,res);
  }),
  app.post('/addnew', function(req,res){
    tigers.add_in_new_tiger(req,res);
  }),
  app.get('/info/:guy', function(req, res){
    tigers.show_this_info(req,res);
  }),
  app.get('/tigers/edit/:guy', function(req,res){
    tigers.edit_this_tiger(req,res);
  }),
  app.post('/tigers/update/:guy', function(req,res){
    tigers.update_this_tiger(req,res);
  }),
  app.post('/tigers/destroy/:cat', function(req,res){
    tigers.remove_this_tiger(req,res);
  });
}
