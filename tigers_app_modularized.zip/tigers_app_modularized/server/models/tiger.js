// require mongoose
var mongoose = require('mongoose');
// create the schema
var TigerSchema = new mongoose.Schema({
  name: String,
  location: String,
  prey: String
})
// register the schema as a model
var Tiger = mongoose.model('Tiger', TigerSchema);
