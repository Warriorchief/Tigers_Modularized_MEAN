var mongoose = require('mongoose');
var Tiger = mongoose.model('Tiger');
module.exports = {
  index: function(req, res){
    Tiger.find({}, function(err,data){
      if (err){
        console.log("there was an error");
        res.send(err);
        console.log(err);
      }
      else{
        console.log("loading the index page");
        res.render('index',{tigers:data});
      }
    })
  },

  show_blank_new_form: function(req,res){
    res.render('addnew');
  },

  add_in_new_tiger: function(req,res){
    var new_tiger = new Tiger(req.body);
    new_tiger.save(function(err) {
      if(err) {
        console.log('something went wrong');
      }
      else {
        console.log('successfully added a tiger!');
        res.redirect('/');
      }
    })
  },

  show_this_info: function(req,res){
    Tiger.find({_id:req.params.guy}, function(err,data){
      if (err){
        console.log("there was an error")
        res.send(err);
        console.log(err);
      }
      else{
        res.render('infopage',{this_tiger:data});
      }
    })
  },

  edit_this_tiger: function(req,res){
    Tiger.find({_id:req.params.guy},function(err,data){
      if (err){
        console.log("there was an error");
      }
      else{
        console.log("have located the tiger's data and it is:");
        console.log(data);
        console.log("going to packege this as a dictionary object in this way: {this_tiger}")
        res.render('edit',{this_tiger:data});
      }
    })
  },

  update_this_tiger: function(req,res){
    console.log("updating this particular tiger through post");
    console.log("POST DATA",req.body);
    Tiger.update({_id:req.params.guy},{name:req.body.name,location:req.body.location,prey:req.body.prey},function(err){
      if(err){
        console.log("there was an error");
      }
      else{
        res.redirect('/');
      }
    })
  },

  remove_this_tiger: function(req,res){
    Tiger.remove({_id:req.params.cat}, function(err){
      if (err){
        console.log("something went wrong")
      }
      else{
        console.log('successfully removed a tiger!')
        res.redirect('/');
      }
    })
  }

}




  // show: function(req, res) {
  //   Tiger.find({}, function(err, tigers) {
  //     res.render('tigers', {tigers: tigers});
  //   })
  // },
  // create: function(req, res) {
  //   console.log(req.body);
  //   console.log("\n\n this is end of  body")
  //   var tiger = new Tiger({name: req.body.name, location: req.body.location, prey:req.body.prey});
  //   quote.save(function(err) {
  //     if(err){
  //       console.log("something went wrong");
  //     } else {
  //       res.redirect('/');
  //     }
  //   })
  // }
